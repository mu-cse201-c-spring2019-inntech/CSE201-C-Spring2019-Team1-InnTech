﻿CREATE TABLE GameApps(
		gameId		int			primary key			identity,
		name		varchar(max)		not null,
		genre		varchar(max)		not null,
		developer	varchar(max)		not null,
		platform	varchar(max)		not null,
		rating		float				not null
		)

BULK INSERT GameApps
FROM 'C:\Users\14260\Desktop\GameApps.txt'
WITH  (
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n',
		FIRSTROW = 2,
		keepIDENTITY
)

select * from GameApps